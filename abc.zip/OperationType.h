#ifndef OPERATIONTYPE_H
#define OPERATIONTYPE_H

#include <set>
#include "Transaction.h"

enum OperationType {
    READ, WRITE
};

#endif